package com.hospital.hms_medicare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HmsMedicareApplication {

	public static void main(String[] args) {
		SpringApplication.run(HmsMedicareApplication.class, args);
	}

}
