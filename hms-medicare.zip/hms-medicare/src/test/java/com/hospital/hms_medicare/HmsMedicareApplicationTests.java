package com.hospital.hms_medicare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HmsMedicareApplicationTests {

	@Test
	void contextLoads() {
	}

}
